/// main.cpp
/***********************************************************************
Matricas tests. Izveidot C++ realizāciju
klasei Matrica, kas apraksta divdimensiju matricu ar
naturālu skaitļu elementiem un darbības ar to.
Klasei izveidot šādas metodes:
(1) konstruktors, kas izveido matricu ar m rindām un n kolonnām un
aizpilda vērtības ar nullēm,
(2) konstruktors, kas izveido matricu kā citas matricas kopiju,
(3) destruktors, kurš paziņo par objekta likvidēšanu,
(4) metode sumrin(r), kas aprēķina matricas elementu summu rindā r,
(5) metode mainit(r, k, v),
kas piešķir matricas r-tās rindas k-tās kolonnas elementam vērtību v,
(6) metode drukat(), kas izdrukā uz ekrāna matricu.
Izveidot CodeBlocks projektu ar sastāvdaļām –
Matrica.h (klases deklarācija),
Matrica.cpp (klases metožu realizācijas) un
main.cpp (objektu veidošana un metožu izsaukšana).
Pārbaudīt realizāciju, veidojot vairākus
Matrica klases objektus gan tiešā veidā, gan dinamiskā veidā.
***********************************************************************/
/// Autors: Uldis Straujums
/// Veidota: 02.12.2008.
/// Mainīts: 08.12.2010. Pielāgots Datorikas fakultātes norādījumiem
/// Mainīts: 07.12.2011. Pielikta iespēja mainīt visus elementus matricā
/// Mainīts: 01.12.2020. Programmas kodējums nomainīts uz UTF-8
/// Mainīts: 1.12.2022. Cieti iekodēti dati un paredzamie rezultāti
#include <iostream>
using namespace std;
#include "Matrica.h"

int main()
{
    Matrica m1;  /// noklusēti 2 rindas un 3 kolonnas
    m1.drukat();                /// 0 0 0
                                /// 0 0 0
    m1.mainit(2,1,5);
    m1.drukat();
                                /// 0 0 0
                                /// 5 0 0
    cout<<m1.sumrin(2)<<endl;   /// 5
    Matrica m2(m1); /// m2 aizpilda ar m1 vērtību
    m2.drukat();
                                /// 0 0 0
                                /// 5 0 0

    cout << "Dinamiski veidosim matricu" << endl;
    Matrica *dmatr;
    dmatr = new Matrica(2, 3);
    cout << "Dinamiski izveidota matrica" << endl;
    dmatr->drukat();
                                /// 0 0 0
                                /// 0 0 0
    dmatr->mainit(2,1,5);
    dmatr->drukat();
                                /// 0 0 0
                                /// 0 5 0

    cout << "Dinamiskas matricas elementu summa "
         << "2.rindā ir "
         << dmatr->sumrin(2) << endl;
                                /// 5
cout << "Izveido objektu ar kopijas konstruktoru"<< endl;
    Matrica m3(*dmatr);
    m3.drukat();
                                /// 0 0 0
                                /// 0 5 0
    Matrica* dmatr2;
    dmatr2 = new Matrica(m3);
    dmatr2->drukat();
                                /// 0 0 0
                                /// 0 5 0
    delete dmatr;
    delete dmatr2;

    return 0;
}
