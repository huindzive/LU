/// Matrica.h
/*********************
Klase Matrica, kas apraksta divdimensiju matricu ar
naturālu skaitļu elementiem un darbības ar to.
Klasei izveidotas šādas metodes:
(1) konstruktors, kas izveido matricu ar n rindām un m kolonnām un
aizpilda vērtības ar nullēm,
(2) konstruktors, kas izveido matricu kā citas matricas kopiju,
(3) destruktors, kurš paziņo par objekta likvidēšanu,
(4) metode sumrin(r), kas aprēķina matricas elementu summu rindā r,
(5) metode mainit(r, k, v),
kas piešķir matricas r-tās rindas k-tās kolonnas elementam vērtību v,
(6) metode drukat(), kas izdrukā uz ekrāna matricu.
***********************/
/// Autors: Uldis Straujums
/// Veidota: 02.12.2008.
/// Mainīts: 02.12.2020. Pievienota metode, kas ļauj piešķirt citu objektu

class Matrica
{
     private:
              int m; /// rindu skaits
              int n; /// kolonnu skaits
              int **matr;
     public:
              Matrica(int m = 2, int n = 3);
              Matrica(const Matrica& m2);
              ~Matrica();
              int sumrin(int r); /// aprēķina matricas elementu summu rindā r
                                 /// r=1..m
                                 /// Ja nekorekts r,
                                 /// atgriež -1
              void mainit(int r, int k, int v); /// piešķir matricas r-tās rindas k-tās kolonnas elementam
                                                /// vērtību v
                                                ///r=1..m;
                                                /// k=1..n;
                                                /// v>=0
              void drukat();     /// izdrukā uz ekrāna matricu
 };


