/// Matrica.cpp
/*********************
Klase Matrica, kas apraksta divdimensiju matricu ar
naturālu skaitļu elementiem un darbības ar to.
Klasei izveidotas šādas metodes:
(1) konstruktors, kas izveido matricu ar n rindām un m kolonnām un
aizpilda vērtības ar nullēm,
(2) konstruktors, kas izveido matricu kā citas matricas kopiju,
(3) destruktors, kurš paziņo par objekta likvidēšanu,
(4) metode sumrin(r), kas aprēķina matricas elementu summu rindā r,
(5) metode mainit(r, k, v),
kas piešķir matricas r-tās rindas k-tās kolonnas elementam vērtību v,
(6) metode drukat(), kas izdrukā uz ekrāna matricu.
***********************/
/// Autors: Uldis Straujums
/// Veidota: 02.12.2008.
/// Mainīts: 07.12.2011. Papildināta argumentu kontrole metodēm
#include <iostream>

using namespace std;
#include "Matrica.h"

Matrica::Matrica(int m, int n)
{
     cout << "Objektam " << this
          << " tiek pieprasīta atmiņa matricas elementiem" << endl;
     this->m = m>=1?m:2;
     this->n = n>=1?n:3;
     matr = new int*[this->m];
     for (int i=0; i<this->m; i++)
      matr[i] = new int[this->n];
     cout << "Matricai ir piešķirta atmina " << matr << endl;

     for (int i=0; i<this->m; i++)
       for (int j=0; j<this->n; j++)
          matr[i][j] = 0;
}
Matrica::Matrica(const Matrica& m2)
{
    cout << "Objektam " << this
          << " tiek pieprasīta atmiņa matricas elementiem" << endl;
    m=m2.m; n=m2.n;   /// m2.m un m2.n jau ir korekti
    matr = new int*[m];
     for (int i=0; i<m; i++)
      matr[i] = new int[n];
    for (int i=0; i<m; i++)
       for (int j=0; j<n; j++)
          matr[i][j] = m2.matr[i][j];
   cout << "Matricai ir piešķirta atmina " << matr << endl;

}
Matrica::~Matrica()
{   for (int i=0; i<m; i++)
      delete [] matr[i];
    delete []matr;
     cout << "Matricai ir atbrīvota atmina " << matr << endl;
      cout << "Objektam " << this
           << " tiek atbrīvota atmiņa" << endl;
}
int Matrica::sumrin(int r) /// /// aprēķina matricas elementu summu rindā r
                           /// r=1..m,
                           /// Ja nekorekts r, atgriež -1
{
  int s=0;
  if (r>=1 && r <=m)
     for (int j=0; j<n; j++)
       s+=matr[r-1][j];
    else return -1;
  return s;
}
void Matrica::mainit(int r, int k, int vertiba) /// piešķir matricas r-tās rindas k-tās kolonnas elementam
                                                /// vērtību v
                                                ///r=1..m; k=1..n
                                                /// vertiba>=0
{
  if ((r>=1 && r <=m)&&(k>=1 && k <=n)&& vertiba >=0)
     matr[r-1][k-1] = vertiba;
}
void Matrica::drukat() /// izdrukā uz ekrāna matricu
{
   cout << "Matricas elementi ir:" << endl;
   for (int i=0; i<m; i++)
    {for (int j=0; j<n; j++)
     cout << matr[i][j] << ' ';
     cout << endl;
    }
    return;
}



