/// main.cpp
/// Date klases objektu veidošana un metožu izsaukšana
#include<iostream>
#include"Date.h"
using namespace std;

int main()
{
    /// Tieši veido objektu d un pielieto metodes
    Date d(11, 24, 2022);
    d.print();             /// 11 24 2022
    /// Dinamiski veido objektu dind un pielieto metodes
    Date* dind;
    dind = new Date(11, 24, 2022);
    dind->print();        /// 11 24 2022
    delete dind;
    /// Tieši veido objektu d2 ar konstruktoru ar noklusētām vērtībām
    Date d2;
    d2.print();             /// 1 1 1900
    /// Pārbauda kļūdainu objekta d3 veidošanu (nekorekta februāra diena)
    Date d3(2, 30, 2022);
    d3.print();             /// piešķirtas korektas vērtības 2 1 2022
    /// Pārbauda kļūdainu objekta d4 veidošanu (nekorekts mēnesis)
    Date d4(13, 30, 2022);
    d4.print();             /// piešķirtas korektas vērtības 1 30 2022
}


