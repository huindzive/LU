/// main.cpp
/***********************************************************************
Matricas tests. Izveidot C++ realizāciju
klasei Matrica, kas apraksta divdimensiju matricu ar
naturālu skaitļu elementiem un darbības ar to.
Klasei izveidot šādas metodes:
(1) konstruktors, kas izveido matricu ar m rindām un n kolonnām un
aizpilda vērtības ar nullēm,
(2) konstruktors, kas izveido matricu kā citas matricas kopiju,
(3) destruktors, kurš paziņo par objekta likvidēšanu,
(4) metode sumrin(r), kas aprēķina matricas elementu summu rindā r,
(5) metode mainit(r, k, v),
kas piešķir matricas r-tās rindas k-tās kolonnas elementam vērtību v,
(6) metode drukat(), kas izdrukā uz ekrāna matricu.
Izveidot CodeBlocks projektu ar sastāvdaļām –
Matrica.h (klases deklarācija), Matrica.cpp (klases metožu realizācijas) un
main.cpp (objektu veidošana un metožu izsaukšana).
Pārbaudīt realizāciju, veidojot vairākus
Matrica klases objektus gan tiešā veidā, gan dinamiskā veidā.
***********************************************************************/
/// Autors: Uldis Straujums
/// Veidota: 02.12.2008
/// Mainīts: 08.12.2010 Pielāgots Datorikas fakultātes norādījumiem
/// Mainīts: 07.12.2011 Pielikta iespēja mainīt visus elementus matricā
/// Mainīts: 01.12.2020 Programmas kodējums nomainīts uz UTF-8
#include <iostream>
using namespace std;
#include "Matrica.h"

int main()
{
    int r;
    int m, n;
    int v;

    int ok; /// lietotāja atbilde: 1 - turpināt, 0 - beigt

    do /// paredz atkārtotu programmas izpildi
{
    Matrica m1;  /// noklusēti 2 rindas un 3 kolonnas
    m1.drukat(); /// 0 0 0
                 /// 0 0 0
    m1.mainit(2,1,5);
    m1.drukat();
                   /// 0 0 0
                   /// 5 0 0
    cout << m1.sumrin(2) << endl; /// 5


    cout << "Tieši izveidota matrica ar 2 rindām un 3 kolonnām" << endl;
    do
    {
     cout << "Ievadiet aprēķināmās rindas numuru r, 1<=r<=3:" << endl;
     cin >> r;                    /// 2
    }while (r<1 || r > 3);

    cout << "Matricas elementu summa "
         << r << ".rindā ir "
         << m1.sumrin(r) << endl; /// 5
    cout << endl;
    Matrica m2(m1); /// m2 aizpilda ar m1 vērtību
    m2.drukat();
                                /// 0 0 0
                                /// 5 0 0

    cout << "Dinamiski veidosim matricu" << endl;
    Matrica *dmatr;
    do
    {
     cout << "Ievadiet matricas rindu skaitu:" << endl;
     cin >> m;                   /// 2
    }while (m<1);

    do
    {
     cout << "Ievadiet matricas kolonnu skaitu:" << endl;
     cin >> n;                  /// 3
    }while (n<1);

    dmatr = new Matrica(m, n);
    cout << "Dinamiski izveidota matrica" << endl;
    dmatr->drukat();
                                /// 0 0 0
                                /// 0 0 0
    dmatr->mainit(2,1,5);
    dmatr->drukat();
    cout << "Nomainīsim matricas visu elementu vērtības" << endl;
    for (int i=0; i<m; i++)
      for (int j=0; j<n; j++)
        {
            cout << "Ievadiet matricas "<<i+1<<". rindas "<<
            j+1<<". kolonnas elementa vērtību:"<< endl;
            cin >> v;
            dmatr->mainit(i+1,j+1,v);
                              /// 1 2 3
                              /// 4 5 6
        }
    dmatr->drukat();
                              /// 1 2 3
                              /// 4 5 6
    do
    {
     cout << "Ievadiet aprēķināmās rindas numuru:" << endl;
     cin >> r;                /// 2
    }while (r<1);

    cout << "Dinamiskas matricas elementu summa "
         << r << ".rindā ir "
         << dmatr->sumrin(r) << endl;
                            /// 15
cout << "Izveido objektu ar kopijas konstruktoru"<< endl;
    Matrica* dm3;
    Matrica m4(*dmatr);
    m4.drukat();
                            /// 1 2 3
                            /// 4 5 6
    dm3 = new Matrica((*dmatr));
    dm3->drukat();
                            /// 1 2 3
                            /// 4 5 6
    delete dmatr;


    dm3->drukat(); ///pārbauda, ka dm3 ir sava atmiņa, nevis dmatr atmiņa
                           /// 1 2 3
                        /// 4 5 6
    delete dm3;
    cout << endl;
    m4 = m1;
    m4.drukat();
                         /// 0 0 0
                         /// 5 0 0
    cout << endl;
     cout << " Vai turpināt (1) vai beigt (0)?" << endl;
    cin >> ok;
}while(ok == 1);

    return 0;
}
