/// main.cpp
/// Date klases objektu veidošana un metožu izsaukšana
/// Autors: Uldis Straujums - papildināts  klases Date kods no
/// Deitel & Associates, Inc. and Prentice Hall
#include<iostream>
#include"Date.h"
using namespace std;

int main()
{
    /// Tieši veido objektu un pielieto metodes
    Date d(11, 24, 2022);
    d.print();             /// 11 24 2022
    /// Dinamiski veido objektu un pielieto metodes
    Date* dind;
    dind = new Date(12, 25, 2021);
    dind->print();        /// 12 25 2021
    delete dind;
    /// Pārbauda kopijas konstruktoru
    Date d2(d);
    d2.print();           /// 11 24 2022
}
