/// Person.cpp
#include <iostream>
#include <cstring>
#include"Person.h"
using namespace std;
Person::Person (const char *n, int a)
{
strncpy (name, n, 19); name[19] = '\0';/// garantē korektu zema līmeņa virkni
/// garantē korektu vecuma vērtību
if (a>0 and a<150) age = a;
else age=17;
}
void Person::print ()
{
cout << name << " " << age << endl;
}

