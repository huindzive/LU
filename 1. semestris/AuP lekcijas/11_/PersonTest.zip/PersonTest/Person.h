/// Person.h
#include <iostream>
using namespace std;
class Person
{
char name[20];
int age;
public:
Person (const char*, int);
void print ();
};
