/// PersonTest.cpp
#include <iostream>
#include"Person.h"
using namespace std;

int main ()
{
Person p ("Liz", 19);
p.print ();
};
