/// Date klases deklarācija
/// (C) Copyright 1992-2003 by Deitel & Associates, Inc. and
///Prentice Hall. All Rights Reserved.
/// Modified: Uldis Straujums, 01.12.2020, added copy constructor
/**
 Klase Date(Datums), kas apraksta datumu.
**/
class Date {

public:
   Date( int = 1, int = 1, int = 1900 ); /// default constructor
   Date(const Date &d); /// copy constructor
   void print() const;  /// print date in month/day/year format
   ~Date();  /// provided to confirm destruction order
private:
   int month;  /// 1-12 (January-December)
   int day;    /// 1-31 based on month
   int year;   /// any year

   /// utility function to test proper day for month and year
   int checkDay( int ) const;

}; /// end class Date
