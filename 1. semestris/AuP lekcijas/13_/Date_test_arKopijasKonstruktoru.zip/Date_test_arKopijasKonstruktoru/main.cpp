/// main.cpp
/// Date klases objektu veidošana un metožu izsaukšana
#include<iostream>
#include"Date.h"
using namespace std;

int main()
{
    /// Tieši veido objektu un pielieto metodes
    Date d(11, 24, 2020);
    d.print();             /// 11 24 2020
    /// Dinamiski veido objektu un pielieto metodes
    Date* dind;
    dind = new Date(11, 24, 2020);
    dind->print();        /// 11 24 2020
    delete dind;
    Date d2(d);
    d2.print();           /// 11 24 2020
}
