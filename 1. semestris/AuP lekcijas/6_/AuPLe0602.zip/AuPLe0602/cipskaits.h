#ifndef ___CIPSKAITS___
#define ___CIPSKAITS___
/*******************************************************
int cipskaits(int n);
Funkcija cipskaits(n),
kas atgriež kā rezultātu vesela skaitļa n ciparu skaitu
*******************************************************/
int cipskaits(int n);
#endif // ___CIPSKAITS___
