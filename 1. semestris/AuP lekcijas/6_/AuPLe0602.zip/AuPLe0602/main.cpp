/// main.cpp
/***************************
AuPLe0602. Izveidot C++ projektu AuPLa0601, kurā tiek atrisināts sekošs uzdevums.
Lietotājs ievada N veselus skaitļus. Skaitļu skaitu N (N <=100) uzdod lietotājs.
Jāaprēķina un jāizdrukā katra ievadītā skaitļa ciparu skaiti.
Skaitļa ciparu skaita aprēķināšanai jāizveido funkcija cipskaits(sk),
kas atgriež kā rezultātu skaitļa sk ciparu skaitu.
Projektam jāsastāv no
main funkcijas faila main.cpp,
funkcijas cipskaits galvenes(header) faila cipskaits.h un
funkcijas cipskaits realizācijas faila cipskaits.cpp.
Jābūt iespējai projektu izpildīt atkārtoti, neizejot no projekta.

***********************************/
/// Autors: Uldis Straujums
/// Izveidota: 11.10.2021.

#include <iostream>
#include "cipskaits.h"
using namespace std;

int main()
{
    int N;         // doto skaitļu skaits
    int sk;        // kārtējais ievadītais skaitlis
    int cipsk;     // dotā skaitļa ciparu skaits
    int ok;            // lietotāja atbilde: 1- turpināt, 0, beigt

do
{
    cout << "Ievada N veselus skaitļus" << endl;
    cout << "Aprēķina un izdrukā katra ievadītā skaitļa ciparu skaitu" << endl;
    cout << endl;

    /// Ievada no tastatūras skaitļu skaitu N, 1<=N<=100
    do
    {
        cout << "Ievadiet skaitļu skaitu N, 1<=N<=100:" << endl;
        cin >> N;
     if ((N<1)|| (N>100)) cout <<"Kļūdains skaitļu skaits, 1<=N<=100" << endl;
    }while((N<1)|| (N>100));

    /// Ievada no tastatūras N veselus skaitļus,
    /// aprēķina un izdrukā katra skaitļa ciparu skaitu
    for (int i=0;i<N;i++)
    {
        cout << "Ievadiet " <<i+1<< ". veselu skaitli:" << endl;
        cin >> sk;
        cipsk = cipskaits(sk);
        cout << "Skaitļa "<<sk << " ciparu skaits ir " << cipsk << endl;
    }

    cout << endl;
    cout << " Vai turpināt (1) vai beigt (0)?" << endl;
cin >> ok;
} while (ok == 1);

    return 0;
}
/********* Testu plāns ******************
N    skaitļi    paredzamais rezultāts
3    124 0 17   3 1 2
0               prasa atkārtot ievadi
1    17         2
****************************************/
