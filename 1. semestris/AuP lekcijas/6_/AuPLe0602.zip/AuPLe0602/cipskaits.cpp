/*******************************************************
int cipskaits(int n);
Funkcija cipskaits(n), kas
kas atgriež kā rezultātu vesela skaitļa n ciparu skaitu
*******************************************************/
#include "cipskaits.h"
int cipskaits(int n)
{
    int cskaits=0;
    if (n<0)n=-n;  /// Panāk, ka n ir naturāls
    do
    {
     n/=10;
     cskaits++;
    }while(n>0);
    return cskaits;
}
