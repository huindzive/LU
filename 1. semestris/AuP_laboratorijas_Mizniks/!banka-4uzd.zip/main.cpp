#include <iostream>
#include "program.h"
using namespace std;
int main() {
	double atlikums=0, likme=0;
	int izvele, dienas;
	cout << "Lai izveidotu kontu, ievadiet sakuma summa un likmi!: ";
	cin >> atlikums >> likme;
	cout << endl;
	///konta izveide
	konts konts_1(atlikums, likme);
	double papildinajums=0, jauna_likme=0, samazinajums=0, valuta=0;
	int darbiba=1;
	while(darbiba!=0){
            cout<<"Lai parbauditu atlikumu, ievadiet (1)"<<endl;
            cout<<"Lai papildinatu kontu, ievadiet (2)"<<endl;
            cout<<"Lai iznemtu naudu, ievadiet (3)"<<endl;
            cout<<"Lai mainitu procentu likmi, ievadiet (4)"<<endl;
            cout<<"Lai aprekinatu uzkrato summu, ievadiet (5)"<<endl;
            cout<<"Valutas kalkulators, lai atvertu ievadiet (6)"<<endl;
            cout<<"Lai beigtu darbu, ievadiet (0)"<<endl;
            cin>>darbiba;
            if((darbiba<0)or(darbiba>6))
            {
                while((darbiba<0)or(darbiba>6))
                {
                cout<<"Nezinama darbiba, megini velreiz: ";
                cin>>darbiba;
                }
            }
            if(darbiba==1)
            {
                konts_1.drukat();
            }
            if(darbiba==2)
                ///konta papildinasana
            {
                cout << "Ievadiet summu, par cik papildinat kontu!: ";
                cin >> papildinajums;
                konts_1.papildinat(papildinajums);
                konts_1.drukat();
            }
            if(darbiba==3)
            {
                ///naudas iznemsana
                cout << "Ievadiet summu, par cik samazinat kontu!: ";
                cin >> samazinajums;
                konts_1.iznemt(samazinajums);
                konts_1.drukat();
            }
            if(darbiba==4)
            {
                ///procentu likmes maina
                cout << "Ievadiet jauno procentu likmi!: ";
                cin >> jauna_likme;
                konts_1.mainit(jauna_likme);
                konts_1.drukat();
            }
            if(darbiba==5)
            {
                ///atlikuma parrekinasana
                cout << "Ievadiet dienas, lai parrekinatu konta atlikumu!: ";
                cin >> dienas;
                konts_1.parrekinat(dienas);
                konts_1.drukat();
            }
              if(darbiba==6)
            {
                ///valutas maina
                    {
                cout << "Ievadiet summu eiro, ko velaties parrekinat: ";
                cin >> valuta;
                cout << "Izvelieties uz kuru valutu velaties parrekinat summu: "<<endl;
                cout<<"EUR uz USD, ievadiet (7)"<<endl;
                cout<<"EUR uz GBP, ievadiet (8)"<<endl;
                cout<<"EUR uz SEK, ievadiet (9)"<<endl;
                cin>>darbiba;
            if((darbiba<7)or(darbiba>9))
            {
                while((darbiba<7)or(darbiba>9))
                {
                cout<<"Nezinama darbiba, megini velreiz: ";
                cin>>darbiba;
                }
            }
            if(darbiba==7)
            {
                konts_1.samainit1(valuta);

            }

            if(darbiba==8)
                {
                konts_1.samainit2(valuta);

                }
            if(darbiba==9)
            {
                konts_1.samainit3(valuta);

            }
            cout<<endl;
	}
	cout<<"Darbs pabeigts"<<endl;
            }}}
