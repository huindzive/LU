#include <iostream>
#include "program.h"
using namespace std;
///konstruktors
konts::konts(double a, double b)
{
	summa = a;
	procenti = b;
}
///destruktors
konts::~konts()
{
	cout << "Veikta destrukcija!";
}
void konts::papildinat(double papildinajums)
{
    ///konta papildinasana
	summa = summa + papildinajums;
}
void konts::iznemt(double samazinajums)
{
    ///naudas iznemsana
	summa = summa - samazinajums;
}
void konts::mainit(double likme)
{
    ///procentu maina
	procenti = likme;
}
void konts::parrekinat(int dienas)
{
    ///konta atlikuma parrekinasana
	summa = summa + ( ( (procenti/100) / 360 * dienas ) * summa );
}
void konts::drukat()
{
    ///konta atlikuma un procentu drukasana
	cout << "Konta atlikums: " << summa << " Euro" << "\n";
	cout << "Pasreizeja likme: " << procenti << " %" << "\n";
}
void konts::samainit1(double valuta)
{
    ///valutas kalkulators uz USD
	valuta=valuta*1.23;
	cout<<"mainas kurss: 1,23"<<endl;
	cout<<"USD:  "<<valuta;

}

void konts::samainit2(double valuta)
{
    ///valutas kalkulators uz GBP
	valuta=valuta*0.9;
	cout<<"mainas kurss: 0,9"<<endl;
	cout<<"GBP:  "<<valuta;
}
void konts::samainit3(double valuta)
{
    ///valutas kalkulators uz SEK
	valuta=valuta*10.04;
	cout<<"mainas kurss: 10,04"<<endl;
	cout<<"SEK:  "<<valuta;
}
