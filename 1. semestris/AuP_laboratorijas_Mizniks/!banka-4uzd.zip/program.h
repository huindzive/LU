#include <iostream>
using namespace std;
class konts {
    ///privatie dati
private:
	double summa = 0, procenti = 0;
	///publiski pieejamie dati
public:
	konts(double a, double b);
	~konts();
	void papildinat(double papildinajums);
	void iznemt(double samazinajums);
	void mainit(double likme);
	void parrekinat(int dienas);
	void drukat();
	void samainit1(double valuta);
	void samainit2(double valuta);
	void samainit3(double valuta);
};
